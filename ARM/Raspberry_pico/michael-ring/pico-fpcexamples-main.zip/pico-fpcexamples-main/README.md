# pico-fpcexamples
Examples for programming the raspberry pi pico with FreePascal

Please see documentation on the freepascal Wiki:

https://wiki.freepascal.org/ARM_Embedded_Tutorial_-_FPC_and_the_Raspberry_Pi_Pico

