Die Quellen sind von Atmel Studio 7.0
/Atmel/Studio/7.0/packs/atmel

https://github.com/avr-rust/avr-mcu/tree/master/packs/atmega

http://packs.download.atmel.com/
